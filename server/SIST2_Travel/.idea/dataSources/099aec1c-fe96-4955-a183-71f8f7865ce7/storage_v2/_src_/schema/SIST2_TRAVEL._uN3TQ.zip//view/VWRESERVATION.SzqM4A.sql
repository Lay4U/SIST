create view VWRESERVATION as
select 
  r.reservationseq as reservationseq,
  r.iscancel as iscancel,
  r.tourseq as tourseq,
  t.name as tourname, 
  (select name from tblmember where id = r.id) as membername,
  t.use as use ,
  t.validdate as validdate,
  t.tourprice as tourprice,
  r.id , case
    when r.ispay = 'n' then '미결제'
    when r.ispay = 'y' then '결제완료'
  end as ispay
  
  from tblreservation r
  inner join tbltour t on t.tourseq = r.tourseq
/

