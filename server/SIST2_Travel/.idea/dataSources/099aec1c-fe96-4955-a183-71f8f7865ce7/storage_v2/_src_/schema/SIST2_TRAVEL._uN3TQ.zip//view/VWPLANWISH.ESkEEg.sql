create view VWPLANWISH as
select 
        w.wishseq,
        p.planseq,
        p.name,
        p.daystarttravel,
        p.dayendtravel,
        p.willshare,
        p.wish,
        p.id as writerid,
        w.id as wisherid,
        (select nick from tblmember where id = p.id) as writernick, 
        (select nick from tblmember where id = w.id) as wishernick, 
        (select name from tblCity where cityseq = p.cityseq) as cityname
    from tblPlan p
        inner join tblPlanWish w
            on p.planseq = w.planseq
/

