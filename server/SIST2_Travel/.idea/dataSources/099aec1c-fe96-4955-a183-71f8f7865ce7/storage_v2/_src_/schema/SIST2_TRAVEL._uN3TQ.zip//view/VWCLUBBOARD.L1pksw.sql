create view VWCLUBBOARD as
select a."TRAVELCLUBSEQ",a."ID",a."NAME",a."SUBJECT",a."VIEWCNT",a."REGDATE",a."ISNEW",a."CONTENT",a."CCNT",a."THREAD",a."DEPTH", rownum as rnum from
    (select 
        travelclubseq, id, 
        (select name from tblMember where id= tbltravelclubboard.id) as name, 
        subject, viewCnt, regdate, 
        (sysdate - regdate) as isnew,
        content,
        (select count(*) from tbltravelClubComment where travelClubCommentseq = tbltravelclubboard.travelclubseq) as ccnt,
        thread, depth
        from tbltravelclubboard order by thread desc) a
/

