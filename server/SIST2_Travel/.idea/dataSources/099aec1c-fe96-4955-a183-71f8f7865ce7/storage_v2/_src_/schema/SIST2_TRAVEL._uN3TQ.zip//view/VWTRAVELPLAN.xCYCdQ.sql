create view VWTRAVELPLAN as
select
    planseq, status, name, daystarttravel, dayendtravel, willshare, wish, theme, id, cityseq,
    (select name from tblCity where cityseq = tblPlan.cityseq) as cityname
    
from tblPlan
/

