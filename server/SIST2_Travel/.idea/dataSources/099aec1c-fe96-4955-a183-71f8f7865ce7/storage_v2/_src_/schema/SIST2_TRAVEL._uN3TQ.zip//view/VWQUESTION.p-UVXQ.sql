create view VWQUESTION as
select a."QUESTIONSEQ",a."ID",a."NAME",a."SUBJECT",a."VIEWCNT",a."REGDATE",a."RECOMMCNT",a."ISNEW",a."CONTENT",a."CCNT",a."THREAD",a."DEPTH", rownum as rnum from 
  (select 
        questionseq,id,
        (select name from tblmember where id = tblquestion.id) as name,
       subject,viewcnt,regdate,recommcnt,
        (sysdate - regdate) as isnew,
        content,
        (select count(*) from tblquestionComment where questionseq = tblquestion.questionseq) as ccnt,
        thread , depth
    from tblquestion order by thread desc) a
/

