create view VWBOARD as
select a."SEQ",a."ID",a."NAME",a."SUBJECT",a."READCOUNT",a."REGDATE",a."ISNEW",a."CONTENT",a."CCNT",a."THREAD",a."DEPTH", rownum as rnum from
    (select
        seq, id,
        (select name from TBLMEMBER where id = b.id) as name,
            subject, readcount, regdate,
            (sysdate - regdate) as isnew,
            content,
            (select count(*) from TBLEVENTCOMMENT where pseq = b.seq) as ccnt,
            thread, depth
             from TBLEVENTBOARD b order by thread desc) a
/

