create view VWFREECOMMENT as
select
    freecommentseq,freeboardseq,id,content, regdate,
    (select nick from tblmember where id = tblfreeComment.id) as nick,
    (sysdate - regdate) as isnew
from tblfreecomment
/

