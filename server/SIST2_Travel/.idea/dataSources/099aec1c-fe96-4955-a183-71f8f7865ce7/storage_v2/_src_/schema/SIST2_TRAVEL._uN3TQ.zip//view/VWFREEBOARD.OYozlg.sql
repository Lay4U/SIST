create view VWFREEBOARD as
select a."FREEBOARDSEQ",a."ID",a."SUBJECT",a."CONTENT",a."VIEWCNT",a."RECOMMCNT",a."REGDATE",a."NICK",a."ISNEW",a."CCNT", rownum as rnum from 
        (select 
    freeboardseq, id,subject, content, viewcnt, recommcnt, regdate,
    (select nick from tblmember where id = tblfreeboard.id) as nick,
    (sysdate - regdate) as isnew,
    (select count(*) from tblFreeComment where freeboardseq = tblfreeboard.freeboardseq) as ccnt
from tblfreeboard) a
/

