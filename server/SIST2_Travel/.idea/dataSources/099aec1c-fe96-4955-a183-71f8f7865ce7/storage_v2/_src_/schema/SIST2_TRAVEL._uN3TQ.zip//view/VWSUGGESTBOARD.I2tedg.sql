create view VWSUGGESTBOARD as
select a."SUGGESTSEQ",a."ID",a."NAME",a."SUBJECT",a."CONTENT",a."VIEWCNT",a."RECOMMCNT",a."REGDATE",a."ISNEW",a."CCNT",a."THREAD",a."DEPTH", rownum as rnum from
    ( select 
        suggestseq, id, 
        (select nick from tblmember where id = tblsuggestBoard.id) as name,
        subject, content, viewcnt, recommcnt, regdate,
        (sysdate - regdate) as isnew,
        (select count(*) from tblsuggestComment where suggestCommentSeq = tblsuggestBoard.suggestSeq) as ccnt,
        thread, depth
    from tblsuggestBoard order by thread desc) a
/

