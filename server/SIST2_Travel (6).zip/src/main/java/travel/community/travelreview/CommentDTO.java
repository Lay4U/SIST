package travel.community.travelreview;

public class CommentDTO {

}
