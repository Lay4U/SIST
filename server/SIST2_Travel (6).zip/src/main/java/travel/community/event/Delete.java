package travel.community.event;

public class Delete {

}
