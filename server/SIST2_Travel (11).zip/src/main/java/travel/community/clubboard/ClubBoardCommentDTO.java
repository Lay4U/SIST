package travel.community.clubboard;
public class ClubBoardCommentDTO {

	private String travelclubcommentseq;
	private String regdate;
	private String content;
	private String travelclubseq;
	private String id;
	private String nick;
	private String isnew;
	private String name;

	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getIsnew() {
		return isnew;
	}
	public void setIsnew(String isnew) {
		this.isnew = isnew;
	}
	
	public String getTravelclubcommentseq() {
		return travelclubcommentseq;
	}
	public void setTravelclubcommentseq(String travelclubcommentseq) {
		this.travelclubcommentseq = travelclubcommentseq;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTravelclubseq() {
		return travelclubseq;
	}
	public void setTravelclubseq(String travelclubseq) {
		this.travelclubseq = travelclubseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
