package travel.community.event;

public class DeleteOk {

}
