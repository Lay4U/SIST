package travel.coupon;

public class CouponDAO {

}
