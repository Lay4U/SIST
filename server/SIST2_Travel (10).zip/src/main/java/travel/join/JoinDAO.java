package travel.join;

public class JoinDAO {

}
