package travel.spot;


public class SightDAO  {


}