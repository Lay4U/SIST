package travel.community.question;

public class CommentDTO {

	private String questioncommentseq;
	private String regdate;
	private String content;
	private String questionseq;
	private String id;
	private String name;
	
	public String getQuestioncommentseq() {
		return questioncommentseq;
	}
	public void setQuestioncommentseq(String questioncommentseq) {
		this.questioncommentseq = questioncommentseq;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getQuestionseq() {
		return questionseq;
	}
	public void setQuestionseq(String questionseq) {
		this.questionseq = questionseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
