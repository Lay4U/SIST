package travel.community.travelreview;

public class TravelReviewBoardDTO {

}
