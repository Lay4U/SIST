package travel.community.travelreview;

public class TravelReviewBoardDAO {

}
