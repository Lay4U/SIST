package travel.community.freeboard;

public class FreeBoardCommentDTO {

	private String freecommentseq;
	private String regdate;
	private String content;
	private String freeboardseq;
	private String id;
	private String nick;
	private String isnew;
	
	
	public String getFreecommentseq() {
		return freecommentseq;
	}
	public void setFreecommentseq(String freecommentseq) {
		this.freecommentseq = freecommentseq;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getFreeboardseq() {
		return freeboardseq;
	}
	public void setFreeboardseq(String freeboardseq) {
		this.freeboardseq = freeboardseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getIsnew() {
		return isnew;
	}
	public void setIsnew(String isnew) {
		this.isnew = isnew;
	}
	
	
}
