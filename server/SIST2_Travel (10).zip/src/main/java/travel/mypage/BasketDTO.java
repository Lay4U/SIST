package travel.mypage;


public class BasketDTO {

	private String basketseq;
	private String id;
	private String tourseq;
	private String validdate;
	private String membername;
	private String tourname;
	private String use;
	private String tourprice;
	private String ispay;
	private String img;
	private String detail;
	
	public String getBasketseq() {
		return basketseq;
	}
	public void setBasketseq(String basketseq) {
		this.basketseq = basketseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTourseq() {
		return tourseq;
	}
	public void setTourseq(String tourseq) {
		this.tourseq = tourseq;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getTourname() {
		return tourname;
	}
	public void setTourname(String tourname) {
		this.tourname = tourname;
	}
	public String getUse() {
		return use;
	}
	public void setUse(String use) {
		this.use = use;
	}
	public String getTourprice() {
		return tourprice;
	}
	public void setTourprice(String tourprice) {
		this.tourprice = tourprice;
	}
	public String getIspay() {
		return ispay;
	}
	public void setIspay(String ispay) {
		this.ispay = ispay;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getValiddate() {
		return validdate;
	}
	public void setValiddate(String validdate) {
		this.validdate = validdate;
	}
	
	
	
	


	
	
}
