package com.test.jsp;

public class User {
	
	private String name;
	private String nick;
	private String info;
	
	public String getFullname() {
		return name;
	}
	public void setFullname(String name) {
		this.name = name;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
	

}
