package com.test.mvc;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Del  extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//아래 두줄 항상 하는 코드 -> 외우고있어라
		RequestDispatcher dispatcher = req.getRequestDispatcher("WEB-INF/views/address/del.jsp");
		dispatcher.forward(req, resp);
		
	}

}
