package travel.mypage;

public class MypageDAO {

}
