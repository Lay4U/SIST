package travel.spot;


public class RoomDAO   {


}