package travel.community.clubboard;

public class ClubBoardDAO {

}
