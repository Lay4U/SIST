package travel.reservation.tour;

public class TourDTO {

}
