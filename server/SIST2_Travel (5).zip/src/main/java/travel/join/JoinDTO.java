package travel.join;

public class JoinDTO {

}
