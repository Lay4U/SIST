package travel.service;

public class ServiceDTO {

}
