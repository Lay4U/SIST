package travel.community.question;

public class CommentDTO {

}
