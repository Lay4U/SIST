package travel.community.question;

public class BoardDTO {

}
