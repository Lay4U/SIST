package travel.community.event;

public class EventDTO {

}
