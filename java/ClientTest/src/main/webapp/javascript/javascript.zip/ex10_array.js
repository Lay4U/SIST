// 배열, Array
// - 자바의 Array + Collection

// int[] nums = new int[3];

var nums = new Array();

nums[0] = 10;
nums[1] = 20;
nums[2] = 30;

console.log(nums);
nums[5] = 50; //사용 금지(중간에 빈 방 두지 말것)

console.log(nums);
console.log(nums[3]);
